#pragma once

class Sound
{
public:
	Sound();
	~Sound();

	static void playCollidingSound();
	static void playBeamMagnum();
};

