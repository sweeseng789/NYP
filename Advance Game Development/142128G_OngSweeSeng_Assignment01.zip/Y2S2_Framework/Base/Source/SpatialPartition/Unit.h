#ifndef UNIT
#define UNIT

#include "Vector3.h"

class Unit
{
	friend class Grid;

public:
	Unit();
	~Unit();

private:
};

#endif
