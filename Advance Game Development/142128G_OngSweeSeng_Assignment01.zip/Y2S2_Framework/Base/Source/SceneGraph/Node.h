#pragma once

class CNode
{
public:
	CNode(void);
	virtual ~CNode(void);
	virtual void Draw(void);
};
