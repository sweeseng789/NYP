1)Controls
WASD - Movement

2)I have created a mountain scene with horror as the theme in mind. Features used in this scene are rain/snow, OBJs, multi-texture terrain, fog, skyplane and sprite animation.