#include "Node.h"

CNode::CNode(void)
{
}

CNode::~CNode(void)
{
}

void CNode::Draw(void)
{
}
