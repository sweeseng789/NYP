var searchData=
[
  ['light',['Light',['../struct_light.html',1,'']]]
];
