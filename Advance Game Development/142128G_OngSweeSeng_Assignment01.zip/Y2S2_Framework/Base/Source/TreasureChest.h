#pragma once
#include "goodies.h"

class CTreasureChest :
	public CGoodies
{
public:
	CTreasureChest(void);
	~CTreasureChest(void);
};
