Controls
1) Movement - WASD
2) Shoot Laser - Spacebar
3) Throw Mine - E
4) Navigate Menu - Up and Down arrow key
5) Enter choice - Enter
6) Go back to menu - Tab